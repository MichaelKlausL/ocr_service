version https://git-lfs.github.com/spec/v1
oid sha256:aaf6e98bfd13adf957b1655ae02527d13c89348148371493cc21e83bba2568d2
size 412
